// Exercise: console.log the result of using Math.round() on 1.5
console.log(Math.round(1.5))

// Exercise: console.log the result of using Math.ceil() on 1.1
console.log(Math.ceil(1.1))

// Exercise: console.log the result of using Math.floor() on 1.8
console.log(Math.floor(1.8))

// Exercise: console.log the result of using Math.random()con
console.log(Math.random())

// Exercise: console.log a random number between 1 - 10 when the page loads
console.log(Math.floor(Math.random() * 10) + 1)
