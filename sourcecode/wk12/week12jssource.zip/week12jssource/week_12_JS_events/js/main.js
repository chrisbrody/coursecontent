// Exercise: Write a function that displays an alert of the current date, using an HTML event hanlder, the Date() object, and toDateString()
var today = new Date()

function htmlEvent() {
    alert(today.toDateString())
}


// Exercise: Write a function that displays an alert of the current time, using a DOM event handler, the Date() object, and toTimeString()

// ****comment lines 4 - 6 and uncomment 13 - 17 to see exercise 2

// function tradEvent() {
//     alert(today.toTimeString())
// }
// var display = document.getElementById('body')
// display.onload = tradEvent


// Exercise: Write a function that displays an alert of the current year, using a DOM event listener, blur instead of onload, the Date() object, and getFullYear()
function eventList() {
    alert(today.getFullYear())
}
var display = document.getElementById('inputEvent')
display.addEventListener('blur', eventList, false)