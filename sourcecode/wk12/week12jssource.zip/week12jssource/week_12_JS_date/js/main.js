//Exercise: Create an instance of the date object
var rightNow = new Date()


//Exercise: Display the current month in the console
console.log(rightNow.getMonth())


//Exercise: Display the current day of the week in the console
console.log(rightNow.getDay())


//Exercise: Display the current hour in the console
console.log(rightNow.getHours())


//Exercise: Display the current minute in the console
console.log(rightNow.getMinutes())


//Exercise: Display the current second in the console
console.log(rightNow.getSeconds())


//Exercise: Display an alert after 2 seconds using setTimeout()
setTimeout(function(){ alert("Hello"); }, 3000);