// create a random number between 1 and 100
var secretNumber = Math.floor((Math.random() * 100) + 1)
// prompt the user for a number
var guess = Number(prompt("choose a number from 1 - 100"))
// track user guess
var guesses = 1;
// max number of tries
var tries = 7

// until the user guesses correct, do this
while(guess != secretNumber) {
	console.log(secretNumber)
	// if guesses is greater or equal to than tries, do this
	if (guesses >= tries) {
		alert("you lose")
		break
	}
	// if guesses is greater than tries, do this
	else if(guess > secretNumber) {
		guesses++
		guess = prompt("Guess Lower")
	} 
	else if (guess < secretNumber) {
		guesses++
		guess = prompt("Guess Higher")
	} 
	
}

// if guess is less than tries, do this
if (guesses < tries) {
	// alert the user they won
	alert("You got it, and it only took you " + guesses + " guesses")
}











