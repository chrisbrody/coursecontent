var text = "Java script is not Java or Script. Javascript is a language in its own right."
var regex = /Java\s*Script/ig

console.log(text.replace(regex, "JavaScript"))

// console.log(text.replace(regex, "<em>$1</em>"))