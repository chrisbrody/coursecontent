//we're using a regular experssion to test the validity of an email address
//all regular espessions start with / and end with /
//the ^ (power symbol) means look at the start of a string
//the $ means look at the end
//including ^ at the beginning and $ at the end means we want to match the full string
//Code in the square brackets[] denotes a set of valid characters
//in the first set of brackets, we're permitting any characters a-z, 0-9, a . symbol, an _ symbol, a % symbol, and a - symbol.
//the following plus sign indicates that we should have 1 or more of those characters
//the @ symbol is used in all email addresses
//In the 2nd brackets, we define our domain, and we're accepting any characters from a-z, 0-9, the . symbol, or the - symbol
//the plus indicates that we must have at least 1 or more of those characters
//The last section tests the domain suffix, such as .com or .net
//so we must have a ., but in regular expressions a . normally means that it can be any character. By using the \ before it, we indicate that it has no meaning, it's just checking that the period itself exists
//the next [] indicate we just want a-z
//the {2,4} indacate that we only want between 2-5 characters


// EXAMPLE REGEX : /^[a-z0-9._%-]+@[a-z0-9.-]+\.[a-z]{2,5}$/


//\s denotes a white space area, such as a space or a tab
//the * means it will find any number of space character, including none
//the i at the end idicates that this expression is not case sensitive
//the g means global, you want to indicate every instance, not just the first

// EXAMPLE REGEX : /Java\s*Script/ig


//2 ways to define a regular expression in javascript
//use it directly (most common)
var regex = /Java\s*Script/ig
console.log(regex)

//creates a new RegExp object
//takes the expression as a string without the starting and ending slashes
//it's then followed by another string with switches ("ig")
//both expressions are identical so you would normally use the first, but the 2nd one allows you to build regular experssiosn where what you're looking for could change
var regex2 = new RegExp("Java\s*Script", "ig")












