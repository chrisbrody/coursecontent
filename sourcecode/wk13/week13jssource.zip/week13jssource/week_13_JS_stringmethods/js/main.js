// Create a string variable with some uppercase and some lowercase letters. Save another variable that converts all the letters of the first to uppercase, and a third variable that converts all the letters of the first to lowercase. Display all three in the console.
var name = " Michael Jordan "

var nameUpper = name.toUpperCase()
var nameLower = name.toLowerCase()
console.log(nameUpper)
console.log(nameLower)

// Use charAt() to display the 5th character of a variable in the console.
console.log(name.charAt(5))

// Use indexOf() to display the first "e" in a string variable in the console.
console.log(name.indexOf("e"))

// Use split() to create an array of all the words in a string variable. Then loop through the array and print each index to the console.
var nameArray = name.split(' ')
for(i = 0; i < nameArray.length; i++) {
	console.log(nameArray[i])
}

// Use trim() to remove whitespaces from the beginning and end of a string variable.
var nameTrim = name.trim()
console.log(nameTrim)

// Use replace() to change all e's to y's in a string variable.
var nameReplace = name.replace('e', 'y')
console.log(nameReplace)









