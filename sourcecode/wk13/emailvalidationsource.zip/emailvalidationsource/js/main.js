// select the html element with id="validateBtn"
var validateBtn = document.getElementById('validateBtn')
// store validation result, false to start because no attempts have been made
var validationResult = false

// validate email function
function validateEmail(inputForm) {
	// store email validation
	var mailFormat = /^[a-z0-9._%-]+@[a-z0-9.-]+\.[a-z]{2,5}$/
	// store user email from name="email1" line 20 index.html
	var userEmail = inputForm.email1
	// if user data passes email validation, do this
	if( userEmail.value.match(mailFormat) ) {
		return validationResult = true
	} 
	// otherwise, do this
	else {
		alert("You have entered an invalid email address!")
		userEmail.focus() 
		return validationResult = false
	}
}

// add event to validate button
validateBtn.addEventListener('click', function() {
	// call validateEmail and pass data from name="form1" line 17 index.html
	validateEmail(document.form1)
	// check result
	console.log(validationResult)
}, false)






