//Create a 3 questions survey and push the answers to an array of objects. The first questions should use checkboxes, the second questions should use select/options, and the third questions should use radio buttons.

//store our survey answers in this array
var surveyArray = []

//submits the form onclick
function submitForm() {

	var form = document.getElementById('form')
	var selected = document.getElementById('select').value
	// select all elements with name="checkbox"
	var checkboxes = form.elements.checkbox
	// select all elements with name="radio"
	var radios = form.elements.radio
	var checkboxesArray = []
	
	// loop through all checkboxes
	for(i = 0; i < checkboxes.length; i++) {
		if(checkboxes[i].checked)
			checkboxesArray.push(checkboxes[i].value)
	}
	
	// loop through radio buttons
	for(i = 0; i < radios.length; i++) {
		if(radios[i].checked)
			var radioValue = radios[i].value
	}

	// create an object from user answers
	var newSurvey = {
		checked: checkboxesArray,
		selected: selected,
		radiod: radioValue
	}
	
	// add newSurvey to survery array
	surveyArray.push(newSurvey)
	
	// check survery array to confrim new object
	console.log(surveyArray)

	// reset form for next user
	form.reset()
}

// add event to submitButton
document.getElementById('submitButton').addEventListener('click', submitForm, false)









