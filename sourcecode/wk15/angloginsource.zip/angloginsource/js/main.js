// In Class Project: Modify the login app to register a new user. Test that a new user can register, and login on the same page without reloading the page. Check to make sure that the username is not already taken and that the password is at least 8 characters long.
var objPeople = [
	{
		username: "sam",
		password: "password25"
	},
	{
		username: "matt",
		password: "password88"
	},
	{
		username: "chris",
		password: "password3"
	}
]







