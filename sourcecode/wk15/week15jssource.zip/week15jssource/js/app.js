// create new angular module called myApp
var app = angular.module('myApp', [])