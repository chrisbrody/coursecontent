// createa angular controller called myCtrl
app.controller('myCtrl', function($scope) {
	// create a object variable called name
	$scope.name = {
		first: 'chris',
		last: 'brody'
	}
	// create a string variable called stringVar
	$scope.stringVar = "Hello World"

})