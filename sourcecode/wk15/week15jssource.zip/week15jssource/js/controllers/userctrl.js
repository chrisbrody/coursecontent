// createa angular controller called costCtrl
app.controller('usersCtrl', function($scope) {
	// create a array variable called users w/3 objects inside
	$scope.users = [
		{ username: 'chris', password: 'password1' },
		{ username: 'matt',  password: 'password2' },
		{ username: 'sam',   password: 'password3' }
	]
})