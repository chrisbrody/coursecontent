// createa angular controller called costCtrl
app.controller('costCtrl', function($scope) {
	// create a number variable called price
	$scope.price = 58
})