// when the page is ready, do this
$(document).ready(function() {
	// alert the user/developter that jQuery is working
	alert('jQuery is working')
})