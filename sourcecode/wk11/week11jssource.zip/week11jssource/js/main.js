// Exercise: Write out 3 restaurant objects using literal notation, include name, seats, and food
var osha = {
	name: 'Osha Thai',
	seats: 55,
	food: "Thai"
}

var oyama = {
	name: 'Oyama',
	seats: 20,
	food: "Sushi"
}

var saroor = {
	name: 'Saroor',
	seats: 40,
	food: "Indian"
}


// Exercise: Write out those same 3 restaurant objects using constructor notation
function Restaurant(name, seats, food) {
	this.name = name
	this.seats = seats
	this.food = food
}

var osha = new Restaurant('Osha Thai', 55, 'Thai')
var oyama = new Restaurant('Oyama', 20, 'Sushi')
var saroor = new Restaurant('Saroor', 40, 'Indian')


// Exercise: Add a new 'booked' property to both types of objects
var osha = {
	name: 'Osha Thai',
	seats: 55,
	booked: 35,
	food: "Thai"
}

var oyama = {
	name: 'Oyama',
	seats: 20,
	booked: 15,
	food: "Sushi"
}

var saroor = {
	name: 'Saroor',
	seats: 40,
	booked: 40,
	food: "Indian"
}


function Restaurant(name, seats, booked, food) {
	this.name = name
	this.seats = seats
	this.food = food
	this.booked = booked
}

var osha = new Restaurant('Osha Thai', 55, 35, 'Thai')
var oyama = new Restaurant('Oyama', 20, 15, 'Sushi')
var saroor = new Restaurant('Saroor', 40, 40, 'Indian')



// Exercise: Create a function in both types of objects that calculates the available seats left at each restaurant, display the results of both types in the console
var osha = {
	name: 'Osha Thai',
	seats: 55,
	booked: 35,
	food: "Thai",
	availableSeating: function() {
		return this.seats - this.booked
	}
}

var oyama = {
	name: 'Oyama',
	seats: 20,
	booked: 15,
	food: "Sushi",
	availableSeating: function() {
		return this.seats - this.booked
	}
}

var saroor = {
	name: 'Saroor',
	seats: 40,
	booked: 40,
	food: "Indian",
	availableSeating: function() {
		return this.seats - this.booked
	}
}


function Restaurant(name, seats, booked, food) {
	this.name = name
	this.seats = seats
	this.food = food
	this.booked = booked
	this.availableSeating = function() {
		return this.seats - this.booked
	}
}

var osha = new Restaurant('Osha Thai', 55, 35, 'Thai')
var oyama = new Restaurant('Oyama', 20, 15, 'Sushi')
var saroor = new Restaurant('Saroor', 40, 40, 'Indian')
