// 1.Project: Write a program that asks the user for her name and greets her with her name.
var username = prompt("What's your name?")



// 2.Project: Modify the previous program such that only the users Alice and Bob are greeted with their names.
if (username == "Alice" || username == "Bob") {
	document.write("Hello " + username)
} else {
	document.write("Go away " + username + "!")
}



// 3.document.getElementById("id").innerHTML = value
document.getElementById("message").innerHTML = "hello"



// 4.use .value to retrieve input data from a form
function getInfo() {
	var username = document.getElementById("username").value
	var password = document.getElementById("password").value
	console.log("you're username is " + username + " and your pasword is " +  password)
}



// 5.arrays
var cars = ["fiat", "benz", "honda", "chrystler"]
console.log(cars[1])



// 6.For loop referencing an array
for(i = 0; i < cars.length; i++) {
	console.log(cars[i])
}



// 7.Project: find the biggest number in an array
var arr = [10, 55, 22, 87, 1];
var big = 0;

function biggest() {
	for(i = 0; i < arr.length; i++) {
		if(big < arr[i]) {
			big = arr[i];
		}
	}
	return big;
}
biggest();
console.log(big);



// 8.Objects
var carObject = 
	{
		make: "fiat",
		year: 2010,
		color: "blue",
		driver: "Sean Connery",
		interior: "wood",
		mpg: 30,
		purcashed: false
	}

console.log(carObject.driver)



// 9.For loop referencing an array of objects
var carArray = [
	{
		make: "fiat",
		year: 2010,
		color: "blue",
		driver: "Sean Connery",
		interior: "wood",
		mpg: 30,
		purcashed: false
	},
	{
		make: "benz",
		year: 2015,
		color: "black",
		driver: "that guy from the transporter",
		interior: "mahogany",
		mpg: 20,
		purcashed: true
	},
	{
		make: "honda",
		year: 2000,
		color: "yellow",
		driver: "Lucy",
		interior: "leather",
		mpg: 35,
		purcashed: false
	}
]

for(i = 0; i < carArray.length; i++) {
	if(carArray[i].year <= 2014) {
		console.log(carArray[i].mpg)
	}
}


// 10.Project: Modify the previous program to create a simple login system utilizinng an an array of user objects
var objPeople = [
	{
		username: "sam",
		password: 31
	},
	{
		username: "matt",
		password: 29
	},
	{
		username: "chris",
		password: 28
	}
]

//login functionality
function getInfo() {
	//retrieve data input from the form
	var username = document.getElementById("username").value
	var password = document.getElementById("password").value
	
	//loop through all the user objects and confirm if the username and passwords are correct
	for(i = 0; i < objPeople.length; i++) {
		if(username == objPeople[i].username && password == objPeople[i].password) {
			console.log(username + " is logged in!!!")
			return
		}
	}

	//error if username and password do not match
	console.log("incorrect username or password")
}